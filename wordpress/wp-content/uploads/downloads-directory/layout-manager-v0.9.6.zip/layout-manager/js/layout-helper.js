// for compatibility with FormsBuilder
if ( typeof BUILDER_NONCE == 'undefined' ) {
    BUILDER_NONCE = LayoutManagerHelper.builder_nonce;
}
